//65130500125 Achmavee Sanuwong

class Movies {

   newmovie = []
 
  constructor(){
return this.newmovie.push(this.newmovie)
  }
    getAllMovies(){
    return this.newmovie
  }
  addMovie(title, director, year, genre){
    return { title:title , director:director , year:year , genre:genre }
  }
  updateMovie(title, updatedDetails) {
    

  }
  deleteMovieByTitle(title) {
    if (title != null || undefined){
      return this.newmovie = []
    }
    // newmovie.delete(title)
  }




}

  
module.exports = Movies

